from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

F=Path(__file__).parent/'figures'
plt.rcParams.update({'font.family':'Nimbus Sans','font.size':10,'text.color':'#202326','pdf.fonttype':42,'savefig.facecolor':'white'})
ink='#354958'; gray='#aeb5b9'; light='#e2e5e7'
def base(h):
    f,a=plt.subplots(figsize=(6.7,h));a.set(xlim=(0,1),ylim=(0,1));a.axis('off');return f,a
def save(f,n):
    f.savefig(F/(n+'.pdf'),bbox_inches='tight',pad_inches=.06)
    f.savefig(F/(n+'.png'),dpi=160,bbox_inches='tight',pad_inches=.06);plt.close(f)

f,a=base(3.2)
events=[('14 FEB','Propuesta y ejecución','Juego: Umbral / Acople / Deriva','S18; S30 · P01'),('19–21 FEB','Elección y denominación','Cambiar formato / palabra por turno','S30 · P02–P03'),('20 SEP','Pregunta y decisión','¿QUÉ CAMBIÓ? / La forma','S16; S30 · P04'),('08–09 OCT','Contraste y continuación','Comprobar elección / ampliar / retomar','S03; S30 · P05–P12')]
for i,(date,title,body,ref) in enumerate(events):
    y=.91-i*.24
    a.text(.015,y,date,fontsize=10,weight='bold',color=ink,va='top')
    a.text(.24,y,title,fontsize=10,weight='bold',va='top')
    a.text(.24,y-.075,body,fontsize=9,va='top')
    a.text(.24,y-.14,ref,fontsize=8,color='#666b70',va='top')
    if i<3:a.plot([.015,.98],[y-.195,y-.195],lw=.65,color=light)
save(f,'17_genealogia_formato')

f,a=base(3.7)
cols=[.22,.48,.74]
for x,t in zip(cols,['Intervención','Oportunidad\nposterior','Resultado']):a.text(x,.97,t,fontsize=9,weight='bold',va='top',color=ink)
data=[('R/M','F:61–74','Revisión general;\nGPT repone $\\kappa_\\beta$.','Fórmula y HTML\nposteriores.','Reposición\nmantenida.'),('5,6 / 5.6','N103–118','Señalamiento;\ncambio de coma.','Petición explícita\ndel nombre.','Reconocimiento\ncon precisión.'),('T023','N73–77','Estilo acordado;\nnueva foto.','Adro reclama\nel hilo del fuego.','Se requiere\nrestitución.'),('Test 2','C2-067–086','Mediación\naceptada.','Revisión útil;\nautoría reabierta.','Ejecución y\nacuerdo divergen.')]
for i,(label,ref,*cells) in enumerate(data):
    y=.79-i*.23
    a.text(.01,y,label,fontsize=10,weight='bold',va='top');a.text(.01,y-.073,ref,fontsize=7.8,color='#666b70',va='top')
    for x,t in zip(cols,cells):a.text(x,y,t,fontsize=9,va='top',linespacing=1.45)
    if i<3:a.plot([.01,.98],[y-.16,y-.16],color=light,lw=.7)
save(f,'18_oportunidades')

f,a=base(3.65)
for x,t in [(.01,'Caso'),(.21,'Registro y correspondencia'),(.71,'Reconstrucción')]:a.text(x,.97,t,fontsize=9,weight='bold',color=ink,va='top')
data=[('Marzo','Informe visual: tres respuestas.\nCotejo JSON: faltan; controles presentes.','Ausencia selectiva\nen el export.'),('A05','Anotador: notificación, gris,\nPNG visible en la misma zona.','Espera seguida\nde aparición.'),('A06','Informe: 15 ciclos, con\n4 detenciones deliberadas.','Interrupción\nidentificada.'),('S28','Revisiones: archivos guardados.\nRegistro: entrega no visible.','Persistencia y entrega\nse distinguen.')]
for i,(label,obs,res) in enumerate(data):
    y=.80-i*.235
    a.text(.01,y,label,fontsize=10,weight='bold',va='top')
    a.text(.21,y,obs,fontsize=9,va='top',linespacing=1.5)
    a.text(.71,y,res,fontsize=9,va='top',linespacing=1.5)
    if i<3:a.plot([.01,.98],[y-.16,y-.16],color=light,lw=.7)
save(f,'19_registros_aplicados')
