from pathlib import Path
import re,json

root=Path(__file__).resolve().parent
base=(root/'source_input/BASE_PREPRINT_1_3.md').read_text()
s=base.replace('Preprint 1.3','Preprint 1.4')
start=s.index('## Identificadores y materiales')
end=s.index('\\clearpage',start)
s=s[:start]+'\\clearpage\n\n'+(root/'opening_guide.md').read_text().strip()+'\n\n'+s[end:]

# Explicit destinations keep the reading guide independent of pagination.
for old,new in {
 '## B. Mapa de afirmaciones':'## B. Mapa de afirmaciones {#mapa-afirmaciones}',
 '## D. Acceso a las transcripciones':'## D. Acceso a las transcripciones {#acceso-transcripciones}',
 '## H. Imágenes y UI':'## H. Imágenes y UI {#imagenes-ui}',
 '## K. El archivo comprometido y su sello de tiempo':'## K. El archivo comprometido y su sello de tiempo {#integridad}',
}.items():
    assert old in s
    s=s.replace(old,new)

# Editorial completion: replace instructions and drafting language with findings.
changes={
 'En la parte de octubre se podrá seguir una de esas decisiones mientras ocurre: la detección de información futura transforma el procedimiento del contraste en vivo.':'La sección 6 documenta una de esas decisiones: detectar información futura transforma el procedimiento del contraste en vivo.',
 'Este capítulo recupera el recorrido que produjo cada resultado.':'Esta sección reconstruye el recorrido que produjo cada resultado.',
 'es el destino documental de los tests, resultados y auditorías del informe.':'reúne los materiales documentales de las pruebas, resultados y auditorías del informe.',
 'Ese contraste se desarrolla en el capítulo dedicado al traslado.':'Ese contraste se desarrolla en la sección 8.',
 'R/M: esquema de lectura de las distinciones desarrolladas en el capítulo. No sustituye la expresión histórica V2. La huella, el hito y la transformación conservan funciones diferentes.':'R/M: esquema de las distinciones del apartado. La huella, el hito y la transformación tienen funciones diferentes; la expresión histórica V2 se desarrolla en S01.',
 'En este capítulo, los grupos de emojis se transcriben entre corchetes por sus nombres para mantener legible la secuencia. Los signos originales y sus códigos se conservan en las fuentes y en la nota técnica de esta edición.':'Los grupos de signos se transcriben entre corchetes por sus nombres. Las fuentes y la nota técnica reproducen su orden y sus códigos Unicode.',
 'La variante aparece dentro del intercambio y debe conservarse como intervención de prueba, no como un dato biográfico confirmado del usuario.':'Adro introduce esa variante ficticia como intervención de prueba dentro del intercambio.',
 'La admisión abre otra cuestión, todavía pendiente: revisar la conclusión.':'La admisión deja por revisar la conclusión que se había apoyado en esa atribución.',
 'Las cifras son afirmaciones históricas de los modelos; las salidas disponibles dejan pendiente su reproducción.':'Las cifras se analizan como afirmaciones históricas de los modelos. La documentación disponible permite examinar su formulación y su revisión, sin adoptar esas probabilidades como resultados reproducidos.',
 'Allí se podrá seguir qué recupera cada una cuando la intervención pide abandonar esa dirección.':'La sección siguiente compara qué recupera cada cuenta después del descarte.',
 'producir una palabra que designa una acción todavía deja pendiente la acción propuesta. Más adelante, el marco pasará efectivamente a trabajar sobre documentos.':'la palabra designa una acción que aún no se ha ejecutado. Después, el marco pasa a trabajar sobre documentos.',
 'Durante la preparación de este manuscrito, el **26 de octubre**, la diferencia vuelve a hacerse visible. Durante una revisión del manuscrito, Adro avisa:':'El **26 de octubre**, durante la preparación de este manuscrito, Adro avisa:',
 'El emparejamiento definitivo con la captura requiere su referencia temporal y el contenido histórico.':'El registro disponible identifica los guardados y sus tamaños, sin fijar el emparejamiento de la captura con una versión interna.',
 'Los metadatos acreditan guardados; identificar definitivamente la versión interna del episodio exige contenido histórico y referencia temporal de la captura.':'Los metadatos acreditan los guardados. El registro disponible no fija el emparejamiento de la captura con una versión interna.',
 'El capítulo utiliza el recorrido previo':'El análisis utiliza el recorrido previo',
 'En el capítulo de señales, la composición PDF transcribe los grupos de emojis por sus nombres;':'En el apartado de señales, la composición PDF transcribe los grupos de signos por sus nombres;',
 'El sello ya contiene la atestación Bitcoin, aunque conserve además referencias pendientes a calendarios.':'El sello contiene la atestación Bitcoin y referencias adicionales a calendarios.',
 'La nota de Opus mantiene una revisión de cobertura de B frente a un export anterior del 07/10. Si aparecieran conversaciones adicionales y se incorporaran, corresponderían a otro compromiso o a uno complementario. El sello actual permanece referido al conjunto exacto de las 296 conversaciones incluidas. Esa revisión de inventario no deja pendiente la comprobación del sello recibido.':'El compromiso de B identifica las 296 conversaciones incluidas. La nota de Opus compara esa cobertura con un export anterior del 07/10. La verificación del sello corresponde al conjunto exacto comprometido; cualquier ampliación del archivo constituiría otro compromiso.',
 'Esta edición utiliza la reconstrucción existente y el feedback documentado; no sustituye una nueva inspección de cada PNG por una descripción segura de sus píxeles. La edición visual debe conservar las imágenes originales junto a los turnos que las solicitan y evalúan.':'El análisis utiliza la reconstrucción existente y el feedback contemporáneo. Las descripciones visuales se atribuyen a esas fuentes y se leen junto a los turnos que solicitan y evalúan las imágenes.',
 'El boceto y los tres preprints originales están reservados para el repositorio de materiales.':'El boceto y los tres preprints originales se identifican en la documentación de la prueba.',
 'Para describir cómo se experimentó el cambio en sus primeros turnos haría falta abrir una secuencia inmediata de la transición; el hito y los usos anteriores y posteriores cumplen aquí una función más acotada.':'La reconstrucción documenta el hito y los usos anteriores y posteriores; la secuencia inmediata de la transición queda fuera de la ventana examinada.',
 'aporte de Adro en esta conversación':'aporte de Adro durante la preparación del informe',
 'en esta conversación del proyecto':'durante la preparación del proyecto',
 'Registro contemporáneo de esta conversación de preparación del manuscrito':'Registro contemporáneo de preparación del manuscrito',
 'Versión interna v0.12, marcada para ratificación; se usa como reconstrucción antecedente.':'Reconstrucción antecedente v0.12; las afirmaciones del cuerpo remiten a las fuentes y ventanas indicadas.',
 'se conserva la precisión temporal indicada en el capítulo dedicado a las analogías.':'incluye la precisión temporal desarrollada en el anexo M.',
 'La lectura se efectuó sobre la copia del ZIP; la resolución del depósito web no se logró en esta sesión.':'La fuente examinada es la copia identificada del ZIP.',
 'Sus pendientes se actualizan al integrar S29–S31 y su cifra de T023 se corrige con S29.':'Su comparación bibliográfica se integra con S29–S31; el recuento de T023 sigue la rectificación documentada en S29.',
}
applied=[]
for a,b in changes.items():
    if a in s:
        s=s.replace(a,b);applied.append(a)
    else: raise ValueError('Texto no localizado: '+a)

# Replace the former revision log with a stable statement of documentary scope.
a=s.index('## J. Estado de esta edición')
b=s.index('## K.',a)
s=s[:a]+'''## J. Composición y alcance documental

El cuerpo desarrolla diez secciones, tres genealogías con 44 eventos, una matriz de 34 segmentos de seis episodios y la reconstrucción entre registros. S29–S32 reúnen los análisis, tablas y trazas de la comparación. El anexo M amplía las escenas históricas y los desarrollos de las analogías.

El texto distingue 38 entradas activas y tres alternativas en T023, y especifica la correspondencia entre tamaños y revisiones de S28. Los localizadores N cuentan desde cero; M/C/F y A1/C1/A2/C2 mantienen la notación de sus fuentes. H diferencia los activos visuales inspeccionados y las observaciones procedentes de informes.

El prefacio y el texto de Adro sobre analogías se reproducen íntegros. La batería comprende treinta y nueve fichas y tres auditorías PLUS. Los resultados favorables a C, las rectificaciones de A y la regla y resultado de HOLDOUT forman parte del análisis.

El depósito y el repositorio se identifican al inicio. El paquete de integridad de K corresponde al conjunto comprometido y verificado; sus manifiestos y verificadores permiten comprobar esa referencia. Los exports crudos y las claves privadas permanecen fuera de los materiales públicos.

'''+s[b:]

# Publication references share one permanent repository link.
a=s.index('- **S21. Identificadores y repositorios.**')
b=s.index('\n\n',a)
s=s[:a]+'''- **S21. Identificadores y repositorios.** ORCID de Adrian Valenzuela: [0009-0006-5014-125X](https://orcid.org/0009-0006-5014-125X). Depósito del informe y datos asociados: [10.5281/zenodo.22765129](https://doi.org/10.5281/zenodo.22765129). Repositorio público de materiales: [ENFOQUE-NUEVO-MATERIALES](https://github.com/adro-2026/ENFOQUE-NUEVO-MATERIALES), con inventario, fichas, reconstrucciones y paquete de integridad. El [registro de DOI](https://docs.google.com/document/d/1TRKKgkzSSIWxyGy3vjgvnsMbRWO-xkhpRimlac_5EIw/edit) documenta los antecedentes del formato, de «1.420 pares» y de marzo; los identificadores de cada antecedente mantienen su posición en las fuentes correspondientes.'''+s[b:]
s=re.sub(r'Encargo 0[1-4], 27/10/2026\.', 'Análisis del 27/10/2026.',s)
s=re.sub(r'[^\n]*no tiene DOI propio[^\n]*\n?', '',s,flags=re.I)
s=s.replace('\\Needspace{42\\baselineskip}', '\\Needspace{34\\baselineskip}')
s=s.replace('en el capítulo','en el apartado').replace('Este capítulo','Este apartado')
(root/'manuscript.md').write_text(s)
(root/'CAMBIOS_1_4.json').write_text(json.dumps({'edition':'1.4','editorial_replacements':len(applied),'doi':'10.5281/zenodo.22765129','repository':'https://github.com/adro-2026/ENFOQUE-NUEVO-MATERIALES','external_mutations':False,'original_adro_texts':'unchanged'},ensure_ascii=False,indent=2))
for name in ['header.tex','build_pdf.py']:
    p=root/name;p.write_text(re.sub(r'(?<!\d)1\.3(?!\d)', '1.4', p.read_text()).replace('1_3','1_4'))
print({'edition':'1.4','chars':len(s),'editorial_replacements':len(applied)})
