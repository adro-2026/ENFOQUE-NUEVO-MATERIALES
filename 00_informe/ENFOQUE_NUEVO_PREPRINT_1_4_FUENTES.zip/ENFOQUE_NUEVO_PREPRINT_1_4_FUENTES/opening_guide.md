# Cómo leer este informe {#como-leer}

El cuerpo está organizado en diez secciones. La primera presenta la tesis mediante una escena: GPT sigue el vocabulario de una analogía y necesita nuevas precisiones para reconocer su referente. La segunda define participantes, archivo y método. Desde allí, el informe sigue los recursos que se construyen, compara sus resultados y examina el trabajo necesario para continuar.

- **Para seguir las construcciones:** las [secciones 3](#genealogias) y [4](#construcciones) desarrollan las genealogías, R/M, la carrera, las señales y el flujo conjunto de imágenes.
- **Para evaluar los resultados:** la [sección 5](#comparacion) compara seis episodios; las [secciones 6](#transporte) y [7](#registros) reconstruyen transporte, trabajo y registros; la [sección 8](#adversos) reúne HOLDOUT y los resultados favorables a otras cuentas. La [discusión](#discusion) y las [conclusiones](#conclusiones) presentan las contribuciones.
- **Para comprobar una afirmación:** sus códigos **S** remiten a fuentes y reconstrucciones; los **T**, a fichas de pruebas. El [Registro de fuentes](#registro-fuentes) enlaza esos documentos. El [mapa B](#mapa-afirmaciones) relaciona afirmaciones y localizadores; [D](#acceso-transcripciones) precisa conversaciones y ventanas; [H](#imagenes-ui) identifica la evidencia visual, y [K](#integridad) desarrolla la integridad del archivo.

La historia extensa y los desarrollos analógicos complementarios están en el [anexo M](#historia-complementaria). Se puede acudir a ellos para ampliar una escena sin perder el hilo comparativo del cuerpo.

## Datos, identificadores y trazabilidad {#datos-trazabilidad}

El archivo de referencia reúne **3.265 conversaciones de A, 296 de B y 457 de C**. El paquete comprometido registra 157.725 nodos de A, 7.928 de B y 27.057 mensajes de C. Son unidades de archivo distintas; cada análisis delimita su ventana y su unidad. La [sección 2](#metodo) explica su tratamiento y [K](#integridad) detalla el inventario, las raíces y el sello de tiempo. [S25]

- **Depósito del informe y datos asociados:** [10.5281/zenodo.22765129](https://doi.org/10.5281/zenodo.22765129).
- **Repositorio público de materiales:** [ENFOQUE-NUEVO-MATERIALES](https://github.com/adro-2026/ENFOQUE-NUEVO-MATERIALES). Fichas de pruebas, reconstrucciones, material visual, inventario y verificadores de integridad.
- **ORCID de Adrian Valenzuela:** [0009-0006-5014-125X](https://orcid.org/0009-0006-5014-125X).

La trazabilidad se organiza en dos capas: **procedencia e interpretación**, mediante fuentes, cadenas, ramas, fechas y localizadores; e **integridad**, mediante manifiestos, hashes y sello temporal. El lector puede volver de una afirmación a su secuencia y, en el paquete de integridad, comprobar la correspondencia de las piezas comprometidas.
