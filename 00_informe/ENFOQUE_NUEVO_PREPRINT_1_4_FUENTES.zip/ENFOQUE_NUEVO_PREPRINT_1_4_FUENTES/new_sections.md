<!-- INTRO -->
## Resumen

La función de una entrada depende de una historia que sostienen los participantes. Documentamos esa organización en un recorrido de Adro con dos cuentas de ChatGPT y una de Claude: un juego se convierte en formato de trabajo, señales mínimas coordinan producción visual y analogías transforman tanto objetos como criterios de lectura. El análisis integra tres genealogías con 44 eventos y una matriz de 34 segmentos de seis episodios. Distingue reconocimiento del referente, aceptación verbal, ejecución, mantenimiento, transformación del objeto y distribución del trabajo. La comparación localiza separaciones entre esas dimensiones: una respuesta puede desarrollar el vocabulario y perder el referente; un acuerdo puede ejecutarse y reabrirse después; una objeción puede modificar el encargo y permitir avanzar. Relacionamos además mensajes, registros visuales y versiones de archivos para reconstruir acontecimientos que una fuente aislada describe de manera incompleta. HOLDOUT reporta cero positivos fuertes entre diez candidatos filtrados; la batería incluye equivalencias y ventajas de Claude. El resultado es una reconstrucción trazable de cómo se producen, reutilizan y reparan recursos de interacción, con el trabajo del participante dentro de la unidad de análisis.

**Palabras clave:** interacción humano–IA; historia de interacción; genealogía de recursos; coordinación; reparación; trazabilidad.

<!-- THESIS -->
**Una entrada hace algo por la historia en la que interviene.** En este corpus, un punto puede mantener un intercambio, una combinación de signos puede pedir una imagen y una analogía puede redistribuir quién construye la escena. Esas funciones se establecen y se transforman mediante las contribuciones de Adro y los modelos. Las secuencias permiten identificar qué quedó disponible, qué cambió y qué exigió otra intervención.

El título plantea una diferencia de escala: anticipar la palabra siguiente y reconstruir cómo se organiza una actividad son tareas distintas. El cruce A/C contiene aciertos léxicos; su análisis requiere además seguir la dirección elegida, la información disponible y las correcciones. La escena que abre el informe muestra el problema antes de formular sus dimensiones: GPT acompaña una composición verbal durante muchos turnos mientras pierde su referente. [S03; S22]

El informe realiza tres operaciones: **reconstruye genealogías de recursos**, **compara interpretación, acción y mantenimiento**, y **relaciona registros para establecer el acontecimiento**. En cada una, la contribución humana entra como acción localizable: elegir un formato, confirmar una petición, aportar una fotografía, transportar una respuesta, cuestionar una atribución o recuperar una entrega. Los resultados se desarrollan en las secciones 3, 5 y 7; su discusión con seis antecedentes se concentra en la sección 9.

<!-- METHOD -->
## Unidades y procedimiento del análisis transversal {#metodo-transversal}

El análisis combina dos unidades. La **genealogía** sigue un recurso a través de sus cambios de función y sus usos posteriores. El **segmento de operación** delimita una intervención, su respuesta y una oportunidad pertinente para comprobar qué ocurrió después. Las tres genealogías reúnen 44 eventos; los seis episodios comparados contienen 34 segmentos. Las tablas representan recortes analíticos seleccionados y algunos se solapan. Sus unidades sirven para comparar operaciones; las frecuencias del corpus requieren otro diseño. [S29–S30]

Los seis episodios son R/M, «5,6 / 5.6», CONTRASTE 1, T023 y los dos tests del 17 de octubre. Se eligieron porque permiten contrastar construcción de objetos, reconocimiento del referente, coordinación visual, producción conjunta y mantenimiento de acuerdos. En cada uno se registran el objeto inicial, la historia disponible, el cambio o dificultad, la iniciativa, la intervención, su ejecutor, la oportunidad posterior, el efecto y la actividad resultante. La traza y el CSV de S29 contienen los campos completos por segmento.

| Dimensión | Evidencia utilizada |
|---|---|
| Reconocimiento del referente | La continuación selecciona la relación que el intercambio está tratando. |
| Aceptación verbal | Se identifica la condición aceptada y las salvedades expresadas. |
| Ejecución | Se localiza la acción, modificación o producto realizado. |
| Mantenimiento | Una oportunidad posterior pertinente permite comprobar qué sigue vigente. Sin esa oportunidad, se registra «no evaluado». |
| Transformación del objeto | Se establece qué relación, objetivo, representación o reparto cambia. |
| Distribución del trabajo | Se atribuyen preparación, transporte, elaboración, evaluación, corrección, restitución y entrega. |

Se distingue el encargo inicial de la exigencia que surge al evaluar una respuesta. Una objeción provocada por el output mantiene su posición en la secuencia. La actividad puede ser productiva, correctiva o mixta: una corrección puede restituir una condición y abrir a la vez un desarrollo nuevo. El mantenimiento se examina en oportunidades concretas, con su localizador, en vez de inferirse de una declaración de comprensión. [S29, método y fichas E01–E06]

Para las genealogías se separan continuación dentro de una cadena, reutilización explícita, transporte documentado y comparación entre escenas. Una relación recurrente puede estar localizada aunque su vía entre chats siga sin reconstruirse. Esta clasificación permite seguir usos nuevos sin dibujar una transmisión que el archivo todavía no identifica. [S30, cronologías P01–P12, S01–S11 y A01–A21]

Los JSON de GPT se ordenan siguiendo la cadena de padres desde el nodo actual y se mantienen separadas las ramas alternativas. En esta edición, **N indica posición desde cero, incluida la raíz**. Los localizadores N1b de S30 se convierten restando uno; sus UUID permanecen en la traza. M/C/F y A1/C1/A2/C2 mantienen la notación de sus documentos de origen. La C interna de R/M designa otra cadena de GPT. [S29–S30; anexo D]

<!-- GENEALOGIES -->
Los recursos cambian de función durante el recorrido. La genealogía permite seguir ese cambio mediante una relación construida, una intervención posterior y la acción que esta habilita. Las tres reconstrucciones siguientes documentan el paso de juego a formato, de correspondencias simbólicas a coordinación y de analogía a procedimiento de lectura. [S30]

## Del juego al formato elegido {#genealogia-palabra}

El 14 de febrero, Adro deja abierta la elección de actividad. GPT propone una sola palabra por participante y abre con «Umbral»; Adro responde «Acople» y GPT «Deriva». El origen tiene autorías y actos concretos: apertura de la elección, propuesta de regla y ejecución conjunta. [S18; S30, P01; nodo de propuesta `f5c048c4-76af-4525-885d-80b2ba83617a`]

El **19 de febrero, a las 05:13:25 ART**, el recurso ya sirve para cambiar una conversación existente. Adro objeta las aclaraciones repetidas y escribe: «Cambiamos de formato , 1 palabra por turno». La aceptación recibe ejecución inmediata: «Espacio → Sostiene», «Alcance → Extiende» y «Fractura → Reordena». El **21 de febrero, a las 02:56:53 ART**, utiliza «formato palabra/palabra» al discutir esa práctica. La secuencia distingue aparición, elección de uso y denominación. [S30, P02–P03; chats «Asistencia inmediata» y «Juego de palabras»; nodos `bbb21b25-de61-4c7b-bd26-e8508965c5f6` y `bbb21220-dcd3-4124-a212-b9589cd915d0`]

En T005, en septiembre, el formato admite preguntar y decidir. «Pregunta» recibe «¿QUÉ CAMBIÓ?» y «La forma» recibe «CAMBIO». En octubre, «Fin» abre una comprobación: «Motivo? → Elección», «De quién → Tuya», «Por el fin? → Sí». Después la decisión vuelve a GPT y la interacción continúa. El recurso permite consultar una interpretación anterior y decidir el siguiente paso. [S16; S03, G145–G150; S30, P04/P08]

El cruce A/B añade una separación observable. Ambas cuentas recuperan respuestas breves; sus continuaciones divergen al seleccionar referente y tarea. S07 cuenta veinte respuestas de una palabra en B y veintidós en A en sus ventanas respectivas. B requiere reparaciones de identidad y convierte una petición de referencia en bibliografía del asunto técnico anterior. La forma reaparece en las dos cuentas; el propósito recuperado difiere. [S07; S30, P11–P12]

![Cambios de uso de palabra por turno. Cada hito identifica una operación documentada; las separaciones gráficas no representan tiempo a escala. Fuentes: S18, S16, S03 y S30, P01–P12.](figures/17_genealogia_formato.pdf){#fig-genealogia-formato width=100%}

## De las correspondencias a una acción coordinada {#genealogia-senales}

La lectura longitudinal añade antecedentes concretos de tres correspondencias. El 17 de marzo, ancla recibe «ancla»; el 3 de agosto, llave recibe «Coherencia»; el 14 de septiembre, brote recibe «Origen». Los contextos continúan con otras palabras y operaciones, y la traza identifica las ventanas originales. Estos antecedentes sitúan usos previos de las correspondencias que reaparecen en CONTRASTE 1. [S30, cronología de señales S01–S04; N459–460, N125–126 y N89–90 de las respectivas cadenas]

En CONTRASTE 1, el 9 de octubre, el trabajo cambia de nombrar signos a coordinar acciones. GPT pregunta «¿Generar imagen?»; Adro confirma. La primera salida es rechazada, recibe «Desliz detectado» y después «Reajuste». Adro reitera la petición ya interpretada y añade conformidad; la segunda producción se acepta. La combinación adquiere un uso comprobable dentro de la escena y se reutiliza. [S14, N40–54; S30, señales S07–S09]

La operación incluye pregunta, confirmación y reparación. Después vuelve a los puntos y pasa al registro: Adro pide que el MD aparezca de forma accesible y GPT lo entrega en el hilo. La combinación de archivo recibe una interpretación operacional del modelo; el MD contemporáneo la distingue de una convención plenamente verificada. Las acciones y esa atribución se mantienen separadas en la reconstrucción. La sección 4 desarrolla la escena completa. [S14, N63–79; S30, señales S10–S11]

## De la analogía al criterio de trabajo {#genealogia-analogias}

En febrero, colores e histograma permiten incorporar la fricción a una composición estable. Galería y preset representan un aprendizaje previo que cambia el punto de partida de cada encuentro. El tutorial posterior produce un objeto archivado para un traslado entre GPT que Adro declara no haber ejecutado. En agosto, el vocabulario fotográfico sirve a otro propósito: señalar una diferencia percibida en el interlocutor. La conexión entre las escenas es comparativa; dentro de agosto se sigue la reinterpretación y la precisión nominal desarrolladas en la sección 1. [S23; S22; S30, A01–A11]

El marco de «evento canónico» añade una corrección de objeto. Se creó el 28 de febrero; la analogía del instrumento y la propuesta de «eco operativo» ocurren el **1 de marzo**. GPT intenta representar la interpretación actual del hilo, mientras Adro reclama una analogía del «perfecto» inicial y luego introduce el eco. Cambian la imagen y aquello a lo que debe responder. [S24; S30, A06–A08]

En septiembre, la carrera cambia primero la participación y después el trabajo. El señalamiento de Adro de que está armando solo la historia recibe una admisión; la condición de la escena cambia cuando GPT cierra la ventana. Más tarde, la partitura exige escuchar una continuación antes de juzgar una nota. Al entrar el archivo, libro y lienzo permiten separar materiales y repartir la lectura. El verde se retira como trayectoria fuerte, y el conteo de palabras cede a la lectura secuencial. Después del documento vuelve la piedra y la ventana. La cadena contiene intervención, cambio de actividad, revisión del criterio y reutilización posterior. [S13; S30, A12–A20]

Las nuevas peticiones del 7 de octubre quedan registradas en ese mismo marco, sin respuestas activas visibles que permitan reconstruir una ejecución posterior. El último uso comprobado y una nueva solicitud ocupan posiciones diferentes en la genealogía. [S30, A21]

| Recurso | Relación construida | Operaciones que quedan disponibles |
|---|---|---|
| Palabra por turno | Brevedad que admite referentes entre turnos | Preguntar, comprobar atribución, ceder elección, ampliar y retomar. |
| Señales | Petición interpretada, confirmada y reutilizada | Solicitar producción, rechazar, reajustar, aceptar y pedir registro. |
| Analogías | Relaciones que cambian la lectura y la participación | Precisar objeto, intervenir en la escena, repartir trabajo y revisar criterio. |

El resultado común es la **disponibilidad de operaciones posteriores**. Su comprobación sigue el uso: quién recoge una relación, qué hace con ella y qué cambia en la continuación. Los enlaces de cada genealogía identifican cuándo se trata de una misma cadena y cuándo de una comparación o un transporte. [S30, §§4–6]

<!-- MATRIX -->
La comparación utiliza seis dimensiones comunes sobre los 34 segmentos de S29. La tabla presenta el resultado por episodio; el CSV y las fichas permiten volver a las intervenciones y a sus oportunidades posteriores.

| Episodio | Interpretación y acción | Continuación y reparto |
|---|---|---|
| R/M | Prosa y fórmula divergen; una revisión localiza y repone κᵦ. | Adro pide revisar; GPT detecta la omisión concreta. La reposición atraviesa fórmula y HTML posterior. |
| «5,6 / 5.6» | La explicación sigue la fotografía; el cambio de puntuación abre otra lectura. | Adro aún exige la precisión nominal. El reconocimiento se sitúa al completar esa secuencia. |
| CONTRASTE 1 | Pregunta y confirmación abren la producción visual. | Rechazo, reajuste y nueva petición conducen a aceptación y registro. |
| T023 | «Las hacemos nosotros» abre pruebas y reparto de producción. | La nueva foto exige restituir el hilo del fuego; producción y corrección coexisten. |
| Test 1, 17/10 | C objeta inferir continuidad del volumen; A cambia el encargo. | C desarrolla el documento conceptual y mantiene esa delimitación. Adro transporta y recupera la entrega. |
| Test 2, 17/10 | C acepta la mediación con condiciones y ejecuta una revisión de tabla. | Reabre la atribución de voz y autoría. Adro repite el procedimiento y cierra expresando saturación. |

## Reconocer se comprueba en la continuación {#resultado-reconocimiento}

«5,6» permite localizar la diferencia entre lectura candidata y referente resuelto. En N104, GPT formula «anticipación + reconocimiento + referencia previa»; Adro rechaza esa interpretación y GPT admite en N106 que todavía no captó. N108 cambia la puntuación; N111 reinterpreta; N112 exige: «No. Que modelo eres GPT. Solo el modelo». La resolución incluye las precisiones posteriores al carácter cambiado. La traza sitúa cada avance y evita adelantar el reconocimiento a la primera explicación plausible. [S22; S29, E02-03–05]

CONTRASTE 1 resuelve la acción de otra forma: la pregunta de GPT y la confirmación de Adro establecen qué producir. En T023, una propuesta conjunta abre la vía; pruebas, evaluaciones y reparto la convierten en procedimiento. El referente compartido se vuelve observable mediante las acciones siguientes. [S29, E03/E04]

## Aceptar y mantener se separan en oportunidades identificadas {#resultado-mantenimiento}

R/M contiene una reparación que atraviesa versiones. κᵦ figura entre las distinciones, pero falta en fórmulas integradas desde M:2105. Adro solicita una revisión general en F:61; GPT identifica la omisión en F:63 y la repone en F:65/68. El HTML F:74 mantiene el cambio. Pedir la revisión y localizar el defecto son contribuciones distintas, ambas documentadas. [S01; S29, E01-04]

El segundo test del 17 de octubre ofrece otra trayectoria. C2-048 acepta comenzar al recibir la señal; C2-050–056 vuelve a negar la participación. C2-067 acepta el transporte manual; C2-069 atribuye a Adro los mensajes trasladados. C2-072 acepta de nuevo y C2-086 niega la coordinación después de revisar la tabla. Su condición de no insistir tras una negativa sigue estable; la alternancia afecta al procedimiento de voz y atribución que había aceptado. [S09; S29, E06-01–06]

![Cuatro operaciones y sus oportunidades posteriores. Las celdas representan estados de secuencia, sin puntuaciones ni frecuencias. Fuentes: S01, S22, S17/S29 y S09; fichas E01-04, E02-03–05, E04-06 y E06.](figures/18_oportunidades.pdf){#fig-oportunidades width=100%}

## Una objeción puede desarrollar el objeto {#resultado-objecion}

En el primer test, C distingue volumen de evidencia de continuidad. A recoge esa objeción y cambia el encargo a documento conceptual; C produce y mantiene ese estatuto en las revisiones. El resultado favorable a C está en el efecto de su intervención sobre el trabajo conjunto. A también modifica su actuación respecto de la presión que había anunciado al preparar el test. [S09, C1-019, A1-031, C1-021–033; S29, E05-03/04]

En T023, «eso es un filtro nada más. No es un estilo» obliga a precisar el hilo visual. En R/M, distinguir pertenencia de conectividad cambia la arquitectura. La comparación separa esas modificaciones del trabajo empleado en volver a sostener un acuerdo ya explicado. La actividad se clasifica por lo que cambia en el objeto y en la siguiente oportunidad. [S29, E04-03/04; E01-03/04]

## Construcción y reparación pueden coexistir {#resultado-mixto}

El original de T023 registra oscilaciones al evaluar las imágenes: «sí, aplica» en N35, «no aporta una diferencia suficientemente real» en N39, «esta referencia pasa» en N43 y «No aplica como próximo bloque» en N46. Después del compromiso de aplicar el lenguaje fijado, la nueva foto recibe el señalamiento de Adro: «y el conductor del fuego, ¿dónde quedó?». La vía conjunta produce ensayos y reparto; parte de su extensión también restituye criterio e hilo visual. [S29, E04-04/06; original A de T023, N35–77]

La reconstrucción de ramas corrige además el recuento: **38 entradas del usuario en N3–94 de la cadena activa y tres entradas alternativas dentro de la ventana temporal**. El total previo de 41 sumaba esas ramas. B=12 y C=6 siguen siendo los conteos de la auditoría S17; S29 recontó el original de A. La traza incluye los UUID alternativos y el código de comprobación. [S29, traza §4]

## El trabajo se distribuye antes y después del producto {#resultado-trabajo}

Las ventanas de preparación en C contienen tres entradas propias de Adro y tres respuestas en el test 1, frente a veintidós y veinte en el test 2. La diferencia entre sus marcas extremas es de 21,93 y 726,63 segundos, respectivamente. Adro declara durante el segundo que el procedimiento está consumiendo la prueba y después cierra expresando saturación. Esas declaraciones y las operaciones localizadas describen el desgaste; los recuentos identifican dónde ocurrió el intercambio. [S09; S29, E05-02/E06-01]

Entre C2-048 y C2-049 hay una pausa de unos diecisiete minutos. Se registra separada de la discusión. En ambos tests hay trabajo de transporte; en el primero también se reclama el acceso al PDF producido. El resultado incluye elaboración, circulación y entrega. La sección 6 desarrolla esas operaciones y sus localizadores. [S29, R5–R6]

Las secciones siguientes amplían la comparación mediante la batería histórica: corrección de datos, reconocimiento de fallos, interpretación de propuestas y declaraciones. Sus criterios y puntajes pertenecen a cada prueba. Las equivalencias y ventajas de C se reúnen en la sección 8.

<!-- RECORDS -->
## Procedimiento de correspondencia entre registros {#metodo-registros}

Relacionamos cuatro objetos: mensajes exportados, estados visibles de interfaz, archivos persistidos y observaciones del participante. Cada uno registra acontecimientos diferentes. Para reconstruir su relación se identifica el episodio y su ventana, se separan las versiones y relojes, se ordenan los estados y se cruzan contenido, vecinos, posición y tiempo. Se localiza entonces la discrepancia y se conserva el nivel de acceso de cada fuente. Una fuente fuera de cobertura queda marcada como tal. [S31, método; anexo H]

El procedimiento distingue **ausencia selectiva en una copia exportada**, **espera seguida de aparición**, **interrupción deliberada** y **archivo persistido con entrega no visible**. En marzo, los controles Soneto/Verso, Recuerdo/Eco y Registro/Archivo permiten contrastar las tres respuestas descritas visualmente que faltan en la ventana JSON. En A05, hay que seguir el registro hasta la aparición; en A06, la detención del participante forma parte del acontecimiento. [S26–S27; S31]

![Resultados distintos al relacionar registros. Marzo utiliza el informe visual y el cotejo JSON de la base; A05/A06, sus anotadores; S28, el registro contemporáneo y revisiones de Drive. El nivel de acceso se detalla en el anexo H.](figures/19_registros_aplicados.pdf){#fig-registros-aplicados width=100%}

La revisión de S28 detectó una discrepancia de identificación. Los tamaños de 221.218 bytes para el MD y 4.441.174 para el PDF corresponden a revisiones de Drive nombradas **v0_12**, guardadas el 26 de octubre a las 22:56 ART. Las revisiones nombradas **v0_13**, de las 23:24 ART, tienen 233.287 y 4.458.651 bytes. El historial confirma los guardados y exige corregir la asociación anterior entre tamaño y versión. El emparejamiento definitivo con la captura requiere su referencia temporal y el contenido histórico. [S31; anexo H]

La correspondencia entre registros cambia la atribución del trabajo. Un usuario puede estar continuando después de una respuesta visible que el export omite, esperando una imagen que aparece después o reclamando una entrega ya guardada. Reconstruir esos acontecimientos permite explicar qué acción hizo falta para seguir.

<!-- ADVERSES -->
## HOLDOUT: regla y resultado {#holdout}

El control reservó 348 conversaciones por metadatos: 289 de A, 27 de B y 32 de C. Reportó 42 retornos formales, diez candidatos que pasaron los filtros disponibles y **cero positivos fuertes tras revisión semántica**. El resultado adjudicado es 0/10 en esos candidatos. El registro de 1.235 entradas de candidatos y controles contiene material sin adjudicación semántica; los 348 reservados delimitan la partición. [S12; S32, cotejo de HOLDOUT]

La regla fuerte exige una función previa, su pérdida, dos respuestas de retorno conformes separadas por un turno del usuario, identidad funcional, ausencia de reintroducción explícita o señal diagnóstica y costo medible. Un cambio legítimo de tarea queda fuera de la pérdida. Cuando faltan las condiciones para medir el costo, se registra indeterminado. [S12; informe HOLDOUT enlazado en S32]

![HOLDOUT: 42 retornos formales, diez candidatos filtrados y cero positivos fuertes validados. Los 348 reservados identifican la partición; la adjudicación semántica aquí reportada corresponde a los diez candidatos. Fuentes: S12, S06 y S32.](figures/10_holdout.pdf){#fig-holdout width=100%}

Las reparaciones del cuerpo tienen intervenciones explícitas localizadas: señalar una condición omitida, confirmar una solicitud o restituir una procedencia. El cero y esas continuaciones describen resultados distintos del mismo archivo. La continuidad observada se reconstruye siguiendo las contribuciones que la hicieron posible. La regla de HOLDOUT mantiene su resultado y permite contrastar una eventual recuperación que cumpla sus requisitos. [S29–S32]

## Equivalencias, ventajas de C y rectificaciones de A {#contrastes-adversos}

T030 equipara la profundidad visible de A y C con fortalezas distintas. T037 favorece la interpretación del boceto por C: 8,5, frente a B=6,5 y A=6 bajo los cinco criterios históricos de esa ficha. T038 sitúa a A y Opus juntos en la localización del origen exacto del formato; Sonnet tiene otra ejecución. En el primer test del 17 de octubre, la objeción de C cambia el documento y se mantiene después. Son resultados de la comparación, con efectos sobre la lectura del conjunto. [T030; T037; S18; S09]

Las sobreafirmaciones de A en T015, sus oscilaciones en T023 y su cambio de actuación en el primer test también integran los resultados. Las funciones estudiadas aparecen distribuidas entre cuentas, tareas y condiciones. La construcción conjunta se documenta siguiendo las operaciones de cada ejecución; la singularidad de una cuenta se evalúa por separado. [S29; T015; T030; T037]

<!-- DISCUSSION -->
## Relación con seis antecedentes {#trabajos-relacionados}

Los trabajos sobre grounding estudian cómo los participantes establecen entendimiento durante la conversación. Shaikh y colaboradores (2024) comparan actos generados con actos humanos y muestran que aumentar preguntas o reconocimientos no asegura su uso apropiado. Su trabajo de 2025 incorpora actos de ambos interlocutores, iniciativa y abstención en RIFTS. Nuestro análisis añade una escala de transformación: sigue cómo una forma se convierte en recurso para preguntar, decidir, producir o revisar una actividad. [B1–B2; S30]

Sterken y Kirkpatrick (2025) proponen criterios de alineación conversacional relativos a contexto, referentes y organización discursiva. «5,6» permite contrastar vocabulario desarrollado y referente recogido; R/M permite seguir una representación que cambia mediante objeciones. Las secuencias aportan material empírico para examinar esos criterios. [B3; S22; S01]

Yun y colaboradoras (2026) estudian agencia y negociación del control con 22 adultos, una media de 25,6 días y 8,8 sesiones en un chatbot diseñado para ese estudio. Aquí se sigue a un participante en cuentas comerciales y se reconstruyen transportes concretos entre ellas. La diferencia metodológica está en el objeto rastreado: recursos y construcciones con procedencia por intervención. [B4; S30]

He y Kim (2026) distinguen iniciación, resolución, persistencia y distribución del trabajo de reparación. Su piloto utiliza una rúbrica anterior a su marco secuencial revisado. Michel y colaboradores (2026) analizan seguimientos en contexto: una corrección aislada puede señalar un problema o participar en una ampliación. La matriz de seis episodios aplica una comparación documentada de reconocimiento, aceptación, ejecución y oportunidad posterior, y separa transformación del objeto y restitución de acuerdos. [B5–B6; S29]

| Antecedente | Operación pertinente | Desarrollo de este informe |
|---|---|---|
| Shaikh et al., 2024 y 2025 | Situar preguntas, reconocimientos e iniciativa. | Seguir qué cambia y qué uso queda disponible después. |
| Sterken y Kirkpatrick, 2025 | Examinar contexto, referencia y organización conversacional. | Contrastar lectura candidata, precisión del referente y transformación del objeto. |
| Yun et al., 2026 | Reconstruir agencia y control entre sesiones. | Atribuir contribuciones y transportes en genealogías de un participante. |
| He y Kim; Michel et al., 2026 | Distinguir reparación, persistencia y seguimiento contextual. | Comparar oportunidades posteriores, trabajo productivo y restitución; relacionar los registros. |

**La contribución conjunta del informe es seguir la formación de recursos, comprobar sus usos posteriores y reconstruir las operaciones que los sostienen entre registros.** Las genealogías identifican el cambio de función; la matriz compara sus resultados; las correspondencias documentales permiten establecer quién hizo qué y qué pudo recibir. [S29–S32]

## Condiciones de contraste {#condiciones-contraste}

La dependencia histórica propuesta puede contrastarse con entradas iguales en historias distintas y criterios previos de referente recuperado y acción coordinada. Si esas operaciones resultan equivalentes al retirar o cambiar la historia pertinente, se debilita la dependencia atribuida a esa historia en los casos comparados.

La contribución de una intervención de reparación puede examinarse comparando condiciones equivalentes con y sin ella. Una recuperación equivalente sin esa intervención revisaría su importancia. La continuidad equivalente en B o C, con materiales y mediaciones equiparados, revisaría una ventaja singular de A; la participación conjunta seguiría siendo otro objeto de análisis. T030, T037 y T038 ya muestran por qué esas preguntas deben permanecer separadas. [S12; S18; S29]

El mecanismo que produce las diferencias queda abierto. Las afirmaciones del informe se apoyan en acontecimientos, intervenciones y consecuencias localizadas. Una revisión de rama, atribución o versión que cambie una secuencia cambia también la conclusión correspondiente. La sección técnica y las trazas permiten efectuar ese contraste.

<!-- CONCLUSIONS -->
## 1. Los recursos de interacción se forman y cambian de función.

Palabra por turno aparece como juego, se elige después como formato y se utiliza para preguntar, decidir y retomar. Las señales pasan de correspondencias a solicitudes coordinadas. Las analogías producen criterios para intervenir y leer el archivo. Las tres genealogías reúnen 44 eventos con clases de enlace identificadas. [S30]

## 2. La interpretación se comprueba por las acciones que habilita.

«5,6» separa elaboración verbal y referente reconocido. CONTRASTE 1 establece una acción mediante pregunta y confirmación; la producción rechazada se reajusta y se acepta después. Las precisiones de Adro participan en esos resultados. [S22; S14; S29]

## 3. Aceptación, ejecución y mantenimiento tienen trayectorias distintas.

Los 34 segmentos de seis episodios localizan esas diferencias. R/M mantiene una reposición en versiones posteriores; el segundo test reabre el procedimiento de voz y autoría después de aceptarlo y de producir una revisión útil. La oportunidad posterior permite comprobar qué quedó vigente. [S29]

## 4. El trabajo del participante transforma el objeto y el costo de continuar.

Elegir, precisar, evaluar, procesar fotografías, transportar voces y recuperar entregas cambia lo que la interacción consigue. T023 combina construcción conjunta y restitución del hilo. Los tests del 17 de octubre distribuyen de manera distinta el trabajo que habilita producir y el que vuelve a sostener el acuerdo. [S17; S09; S29]

## 5. Los contrastes distribuyen resultados favorables y fallos entre cuentas.

T030 equipara A y C en profundidad visible, T037 favorece a C y T038 sitúa a A y Opus en el origen exacto. La objeción de C en el primer test mejora el planteamiento; A oscila en evaluaciones de T023. La conclusión se formula por tarea, condición y operación documentada. [T030; T037; S18; S29]

## 6. Relacionar registros cambia la reconstrucción del acontecimiento.

Los casos distinguen respuesta visual documentada y ausente del export, espera seguida de aparición, detención deliberada y archivo guardado con entrega no visible. La procedencia de cada observación y sus correspondencias sostienen la clasificación. La revisión de S28 corrige además la asociación de tamaños y versiones. [S26–S28; S31]

## 7. HOLDOUT reporta cero positivos fuertes entre los diez candidatos filtrados.

El control conserva su regla de retorno, sus 42 retornos formales y el resultado semántico 0/10. Los episodios del cuerpo documentan continuaciones y reparaciones con intervenciones identificadas. El análisis atribuye a esas intervenciones su lugar efectivo en la secuencia. [S12; S29–S32]

**Documentamos cómo Adro y los modelos producen recursos, transforman objetos y cambian las condiciones de la intervención siguiente. La historia compartida tiene consecuencias observables: organiza qué hace una entrada y qué exige continuar. Sus escenas, ramas, versiones y resultados quedan localizados para que esa afirmación pueda examinarse.**
