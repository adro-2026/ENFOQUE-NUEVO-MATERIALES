local function escape_tex(s)
  s=s:gsub('\\','\\textbackslash{}')
  s=s:gsub('([#$%%&_{}])','\\%1')
  s=s:gsub('~','\\textasciitilde{}'):gsub('%^','\\textasciicircum{}')
  return s
end
function Code(el)
  local text=escape_tex(el.text)
  if #el.text > 12 then
    return pandoc.RawInline('latex','{\\footnotesize\\texttt{\\seqsplit{'..text..'}}}')
  end
end
function Table(el)
  local n=#el.colspecs
  local widths=nil
  local h2 = n >= 2 and pandoc.utils.stringify(el.head.rows[1].cells[2].contents) or ""
  if n==2 then widths={.35,.65}
  elseif n==3 then widths={.33,.39,.28}
  elseif n==4 then widths={.40,.16,.28,.16}
  elseif n==5 then widths={.34,.09,.19,.19,.19} end
  if h2 == "Ficha" and n==4 then widths={.12,.38,.12,.38} end
  if h2 == "Conversaciones" then widths={.12,.24,.46,.18} end
  if widths then
    for i=1,n do el.colspecs[i][2]=widths[i] end
  end
  return el
end
