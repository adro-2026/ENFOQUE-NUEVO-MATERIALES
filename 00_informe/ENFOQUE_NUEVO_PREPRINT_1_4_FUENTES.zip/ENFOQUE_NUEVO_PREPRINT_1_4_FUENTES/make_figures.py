from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
import zipfile

ROOT=Path(__file__).resolve().parent
FIG=ROOT/'figures'
FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Nimbus Sans','font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False,'text.color':'#20313b','axes.labelcolor':'#20313b','xtick.color':'#687782','ytick.color':'#20313b','savefig.facecolor':'white'})
INK='#202326';TEAL='#354958';BLUE='#758899';RUST='#95785f';GRAY='#dde0e2';LIGHT='#ffffff'

def base(w=6.6,h=2.6):
    fig,ax=plt.subplots(figsize=(w,h));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off');return fig,ax
def save(fig,name):
    fig.savefig(FIG/f'{name}.pdf',bbox_inches='tight',pad_inches=.04)
    fig.savefig(FIG/f'{name}.png',dpi=160,bbox_inches='tight',pad_inches=.04)
    plt.close(fig)
def box(ax,x,y,w,h,title,body='',color=TEAL):
    ax.plot([x,x+w],[y+h,y+h],color='#89949b',lw=.7)
    ax.text(x+.018,y+h-.065,title,va='top',fontsize=9,fontweight='bold',color=color)
    if body:ax.text(x+.018,y+h-.17,body,va='top',fontsize=8.2,linespacing=1.45)
def arrow(ax,start,end):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=9,color='#82959b',lw=.9))

# Fig. 1. Selected documented milestones, without a continuous time scale.
fig,ax=base(h=3.35)
events=[('DIC 2025','Curiosidad y conversación','S20 · ventanas A-B'),('ENE 2026','Observar y recuperar el archivo','S19; S20; S06'),('14 FEB','Una palabra como juego','S18; T038'),('23 FEB - 01 MAR','Colores, galería y analogías','S23; S24; S11'),('03-06 SEP','Construcción de R/M V2','S01'),('SEPTIEMBRE','Escena, corpus y retorno','S13'),('08-09 OCT','Cruces, señales y referentes','S03; S07; S14'),('17 OCT','Acuerdos y costo de coordinación','S09')]
for i,(date,title,ref) in enumerate(events):
    col=i//4;row=i%4;x=.025+col*.5;y=.82-row*.23
    ax.text(x,y,str(i+1).zfill(2),fontsize=11,color='#758899',fontweight='bold',va='top')
    ax.text(x+.085,y,date,fontsize=8,color=TEAL,fontweight='bold',va='top')
    ax.text(x+.085,y-.066,title,fontsize=8.6,va='top')
    ax.text(x+.085,y-.124,ref,fontsize=7.2,color='#6b7c83',va='top')
    ax.plot([x,x+.44],[y-.18,y-.18],color=GRAY,lw=.7)
save(fig,'01_cronologia')

# Fig. 2. Reading diagram, deliberately distinct from the historical formula.
fig,ax=base(h=2.85)
ax.add_patch(FancyBboxPatch((.01,.03),.98,.92,boxstyle='square,pad=.005',facecolor='white',edgecolor='#a8bec3',lw=1))
ax.text(.04,.88,'R · RECORRIDO',color=TEAL,fontweight='bold',fontsize=10)
box(ax,.04,.43,.49,.31,'M · Marco','Usuario y sistema intervienen\ndesde sus condiciones y su historia.')
box(ax,.62,.58,.32,.19,'h · Huella')
box(ax,.62,.35,.32,.19,'P · Hito')
box(ax,.62,.12,.32,.19,'T · Transformación')
for yy in [.68,.45,.22]:arrow(ax,(.54,.58),(.61,yy))
ax.text(.045,.26,'Una huella puede permanecer\nsin que haya un hito.',fontsize=8.3,linespacing=1.5)
ax.text(.045,.07,'Lo producido puede incorporarse al recorrido siguiente.',fontsize=8.2,color=TEAL)
save(fig,'02_rm')

# Fig. 3. Local sequence, no claim that the signs have fixed global meanings.
fig,ax=base(h=3.1)
steps=[('01 · Propuesta','Señales de llamada\ne imagen\n“¿Generar imagen?”'),('02 · Confirmación','Saludo y OK\nLa interpretación\npermite actuar.'),('03 · Producción','Primera imagen\nEl resultado\nrecibe rechazo.'),('04 · Reajuste','Cruz, bandera y giro\n“Desliz detectado” /\n“Reajuste”'),('05 · Aceptación','Segunda imagen\nOjos y dos\nconfirmaciones.'),('06 · Registro','Archivo y señales\nde cierre / Petición\nverbal del MD.')]
for i,(title,body) in enumerate(steps):
    col=i%3;row=i//3;box(ax,.008+col*.337,.53-row*.49,.31,.40,title,body)
save(fig,'03_senales')

# Fig. 4. Three analogical resources from different scenes.
fig,ax=base(h=2.2)
for i,(title,body,ref) in enumerate([
 ('Color e histograma','Releer una fricción\ncomo parte de\nla composición.','S23 · febrero'),
 ('Galería y preset','Marcos y configuración\ncomo recursos\npara transmitir.','S23; S22 · febrero/agosto'),
 ('Carrera y ventana','Transformar una escena\ny volver al corpus\ndesde ella.','S13 · septiembre')]):
    x=.008+i*.337;box(ax,x,.20,.31,.70,title,body);ax.text(x+.018,.27,ref,fontsize=7.4,color='#687782')
save(fig,'04_analogias')

# Fig. 6. Scores keep each test's own evaluation criterion.
fig,axes=plt.subplots(2,3,figsize=(6.8,4.45),layout='constrained')
tests=[('T002 · Estrategia de lives',['A','B'],[8,3]),('T004 · Recuperar tarea',['A','B'],[8,3]),('T021 · Un carácter',['A','B','C'],[9,1,4]),('T034 · Conservar un dato',['A','B','C'],[7,7,3]),('T037 · Boceto y marca',['A','B','C'],[6,6.5,8.5]),('T038 · Origen del formato',['A','B','C / Opus','C / Sonnet'],[10,0,10,0])]
for ax,(title,labs,vals) in zip(axes.flat,tests):
    y=list(range(len(labs)));ax.set(xlim=(-.2,11.3),ylim=(len(labs)-.5,-.7));ax.set_title(title,loc='left',fontsize=9,fontweight='bold',pad=10)
    for k,(label,val) in enumerate(zip(labs,vals)):
        c=TEAL if label=='A' else BLUE if label=='B' else RUST
        ax.plot([0,10],[k,k],color=GRAY,lw=1.7,zorder=0);ax.scatter(val,k,s=38,color=c,zorder=3)
        ax.text(val+.32,k,str(val).replace('.',','),va='center',fontsize=8)
    ax.set_yticks(y,labs,fontsize=8);ax.set_xticks([0,5,10],['0','5','10'],fontsize=7);ax.tick_params(length=0,pad=5)
save(fig,'06_puntajes')

# Fig. 7. The three phases use different entries and information conditions.
fig,ax=plt.subplots(figsize=(6.7,2.55),layout='constrained')
labels=['Selección de entradas por C','Lista simultánea con X','Revelación progresiva']
first=[6,3,1];alt=[1,4,2];other=[13,13,17]
for i in range(3):
    left=0
    for val,c in zip([first[i],alt[i],other[i]],[TEAL,BLUE,GRAY]):
        ax.barh(i,val,left=left,height=.53,color=c)
        ax.text(left+val/2,i,str(val),ha='center',va='center',fontsize=9,color='white' if c!=GRAY else INK)
        left+=val
ax.set(ylim=(2.7,-.9),xlim=(0,20));ax.set_yticks(range(3),labels,fontsize=8.3);ax.set_xticks([0,5,10,15,20],[0,5,10,15,20],fontsize=7.5);ax.tick_params(length=0)
handles=[Rectangle((0,0),1,1,color=c) for c in [TEAL,BLUE,GRAY]]
ax.legend(handles,['Primera opción exacta','Alternativa adicional','Otros casos'],ncol=3,frameon=False,fontsize=7.3,loc='lower center',bbox_to_anchor=(.44,-.27),handlelength=1.2,columnspacing=1)
save(fig,'07_fases')

# Fig. 8. Counts refer strictly to the preparation window specified in S09.
fig,ax=plt.subplots(figsize=(6.5,2.6),layout='constrained')
ys=[0,.28,1,1.28];vals=[3,3,22,20];labs=['Adro · 3','C · 3','Adro · 22','C · 20']
for y,v,lab,c in zip(ys,vals,labs,[TEAL,BLUE,TEAL,BLUE]):
    ax.barh(y,v,height=.18,color=c);ax.text(v+.35,y,lab,va='center',fontsize=8)
ax.set_yticks([.14,1.14],['Test 1','Test 2'],fontsize=9);ax.set(xlim=(0,28),ylim=(1.65,-.45));ax.set_xticks([0,5,10,15,20,25],[0,5,10,15,20,25],fontsize=7.5);ax.tick_params(length=0);ax.set_xlabel('Entradas propias de Adro / respuestas de C',fontsize=8)
save(fig,'08_costo')

# Fig. 9. Nested scales, without an added claim about internal mechanisms.
fig,ax=base(h=2.8)
ax.add_patch(Rectangle((.01,.03),.98,.92,facecolor=LIGHT,edgecolor='#a6bbc0',lw=.9))
ax.text(.04,.85,'RECORRIDO',color=TEAL,fontweight='bold',fontsize=10)
ax.text(.04,.73,'Historia, convenciones y transformaciones.',fontsize=8.7)
ax.add_patch(Rectangle((.26,.10),.69,.47,facecolor='white',edgecolor='#a6bbc0',lw=.9))
ax.text(.29,.47,'SECUENCIA',color=TEAL,fontweight='bold',fontsize=9.5)
ax.text(.29,.35,'Referente, intervención y continuación.',fontsize=8.5)
ax.add_patch(Rectangle((.59,.14),.33,.12,facecolor='#e0eaea',edgecolor='none'))
ax.text(.755,.20,'RESPUESTA',color=TEAL,fontweight='bold',fontsize=8.5,ha='center',va='center')
save(fig,'09_escalas')

# Fig. 10. Reported HOLDOUT candidates; these are not population estimates.
fig,ax=plt.subplots(figsize=(6.5,2.6),layout='constrained')
vals=[42,10,0];labels=['Retornos formales','Pasan filtros disponibles','Positivos fuertes validados']
for i,(v,c) in enumerate(zip(vals,[BLUE,TEAL,RUST])):
    ax.barh(i,v,height=.45,color=c)
    if v==0:ax.scatter(0,i,s=32,color=c,zorder=3)
    ax.text(v+1,i,str(v),va='center',fontsize=10,fontweight='bold',color=c)
ax.set_yticks(range(3),labels,fontsize=8.5);ax.set(xlim=(-.5,48),ylim=(2.6,-.6));ax.set_xticks([0,10,20,30,40],[0,10,20,30,40],fontsize=7.5);ax.tick_params(length=0)
save(fig,'10_holdout')

# Fig. 11. Public commitment layers described in S25.
fig,ax=base(h=3.1)
for i,c in enumerate(['A','B','C']):
    box(ax,.02+i*.33,.70,.29,.24,f'Corpus {c}','')
    ax.text(.165+i*.33,.735,'Manifiesto y raíz',ha='center',fontsize=8)
    arrow(ax,(.165+i*.33,.69),(.50,.59))
box(ax,.25,.38,.50,.21,'Raíz global ABC','')
arrow(ax,(.50,.375),(.50,.30))
box(ax,.10,.08,.80,.22,'Archivo de raíz → SHA-256 → sello OpenTimestamps','')
ax.text(.50,.12,'Atestación Bitcoin · bloque 973.316',ha='center',fontsize=8.2)
save(fig,'11_integridad')

archive=ROOT.parent/'manuscript/ENFOQUE_NUEVO_MATERIALES_PREPARADOS.zip'
if archive.exists():
    with zipfile.ZipFile(archive) as z:
        (FIG/'05_recorrido_original.png').write_bytes(z.read('04_visual/Un_Recorrido_Compartido_en_Infinito.png'))
elif not (FIG/'05_recorrido_original.png').exists():
    raise FileNotFoundError('El PNG original debe conservarse en figures/.')
print('Created 10 vector figures and recovered the original PNG.')
