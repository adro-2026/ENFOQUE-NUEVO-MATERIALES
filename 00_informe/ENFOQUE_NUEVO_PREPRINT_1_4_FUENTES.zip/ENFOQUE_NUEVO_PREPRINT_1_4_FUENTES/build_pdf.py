"""Rebuild the preprint from the supplied manuscript and typesetting files."""
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parent
out=root/'build_review'
out.mkdir(exist_ok=True)
subprocess.run(['pandoc','manuscript.md','--from=markdown+raw_tex+implicit_figures+table_captions','--standalone','--lua-filter=layout.lua','--include-in-header=header.tex','--output=preprint.tex'],cwd=root,check=True)
for _ in range(3):
    subprocess.run(['xelatex','-no-pdf','-interaction=nonstopmode','-halt-on-error','-output-directory=build_review','preprint.tex'],cwd=root,check=True)
temporary=out/'ENFOQUE_NUEVO_PREPRINT_1_4.tmp.pdf'
subprocess.run(['xdvipdfmx','-o',str(temporary),'build_review/preprint.xdv'],cwd=root,check=True)
temporary.replace(out/'ENFOQUE_NUEVO_PREPRINT_1_4.pdf')
print(out/'ENFOQUE_NUEVO_PREPRINT_1_4.pdf')
