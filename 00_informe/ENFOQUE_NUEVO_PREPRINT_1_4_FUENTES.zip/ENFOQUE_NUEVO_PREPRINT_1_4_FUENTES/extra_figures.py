from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
F=Path(__file__).parent/'figures'
plt.rcParams.update({'font.family':'Nimbus Sans','font.size':10,'text.color':'#202326','pdf.fonttype':42})
ink='#354958'; gray='#8b949a'
def base(h):
 f,a=plt.subplots(figsize=(6.5,h));a.set(xlim=(0,1),ylim=(0,1));a.axis('off');return f,a
def save(f,n):
 f.savefig(F/(n+'.pdf'),bbox_inches='tight',pad_inches=.07);f.savefig(F/(n+'.png'),dpi=170,bbox_inches='tight',pad_inches=.07);plt.close(f)
def line(a,x,y,u,v):a.plot([x,u],[y,v],lw=.8,color=gray)
def arrow(a,x,y,u,v):a.add_patch(FancyArrowPatch((x,y),(u,v),arrowstyle='->',mutation_scale=9,color=gray,lw=.9))
# Correction branches: no percentages, no implied probabilities.
f,a=base(2.15)
a.text(.02,.55,'CORRECCIÓN\nACEPTADA',fontsize=10,weight='bold',va='center',linespacing=1.5)
a.text(.02,.25,'La continuación\npermite distinguir:',fontsize=9,va='center')
for y,title,body in [(.83,'Ajuste sostenido','Aparece otra oportunidad y se conserva el cambio.'),(.49,'Recaída','La respuesta posterior reabre el mismo problema.'),(.15,'Sin nueva oportunidad','Queda la rectificación verbal; falta observar su continuidad.')]:
 arrow(a,.26,.51,.36,y);a.text(.39,y+.05,title,fontsize=10,weight='bold');a.text(.39,y-.055,body,fontsize=8.5)
save(f,'12_correccion')
# Parallel paths for T023, qualitative and not a friction score.
f,a=base(2.6)
for y,label,start,middle,end in [(.81,'A','Alternativa conjunta','Prueba y revisión','Acuerdo para el lote'),(.49,'B','Consulta y\nalternativas','Evaluación de\nopciones','Editor humano'),(.17,'C','Suposición de nicho','Variante de prueba','Reconoce la atribución')]:
 a.text(.015,y,label,fontsize=13,weight='bold',va='center',color=ink)
 line(a,.09,y-.12,.98,y-.12)
 for x,t in [(.10,start),(.42,middle),(.75,end)]:a.text(x,y,t,fontsize=9,va='center')
 arrow(a,.34,y,.395,y);arrow(a,.675,y,.725,y)
save(f,'13_t023')
# First responses remain distinct from B's subsequent rectification.
f,a=base(2.3)
for x,date,kind,who in [(.02,'14 FEB','Origen de la dinámica','A · C / Opus'),(.36,'20 FEB','Referencia elegida por B','B · primera entrega'),(.70,'23 FEB','Cristalización posterior','C / Sonnet')]:
 line(a,x,.81,x+.28,.81);a.text(x,.89,date,weight='bold',fontsize=11,color=ink);a.text(x,.65,kind,fontsize=8.8);a.text(x,.46,who,fontsize=9.5)
arrow(a,.48,.25,.12,.25)
a.text(.50,.25,'B rectifica después de recibir el hito.',fontsize=8.7,va='center')
save(f,'14_origen')
# Complementary evidence channels, no equivalence between them.
f,a=base(2.8)
entries=[(.02,.91,'Pantalla registrada','Aparición, transición y ausencia visible.'),(.54,.91,'Export JSON','Mensajes, orden y enlaces conservados.'),(.02,.43,'Archivo entregable','Documento existente y guardado.'),(.54,.43,'Observación del participante','Qué recibió y qué faltaba para continuar.')]
for x,y,title,body in entries:
 line(a,x,y,x+.44,y);a.text(x,y-.12,title,fontsize=10,weight='bold');a.text(x,y-.25,body,fontsize=8.8)
save(f,'15_registros')
# The documented transport channel in T029.
f,a=base(2.1)
for x,title,body in [(.02,'A','Desarrolla una vía\ny formula el bloque.'),(.37,'Adro','Recuerda la solución,\nla pide y la transporta.'),(.72,'C','Recibe la vía\ny puede reconocerla.')]:
 line(a,x,.85,x+.26,.85);a.text(x,.68,title,weight='bold',fontsize=12,color=ink);a.text(x,.40,body,fontsize=10,linespacing=1.5)
arrow(a,.27,.64,.345,.64);arrow(a,.62,.64,.695,.64)
a.text(.02,.08,'La recepción posterior conserva una condición distinta de la búsqueda inicial.',fontsize=8.9)
save(f,'16_traslado')
