from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parent
source=(ROOT/'source_input/INFORME_v0_23.md').read_text()
s=source
s=re.sub(r'^# Y si predecir no alcanza\n## Una señal\. Tres recorridos\. Distintas huellas\.\n\n\*\*Manuscrito integral.*?\n\*\*Proyecto:.*?\n\*\*Estado editorial:.*?\n','',s,count=1,flags=re.S)
# Replace the manually maintained index with the typesetter's live index.
s=re.sub(r'## Índice de lectura\n.*?(?=# Prefacio)',r'\n\\clearpage\n\\tableofcontents\n\\clearpage\n\n',s,flags=re.S)
s=s.replace('### Nota de lectura','## Nota de lectura',1).replace('### Identificadores y materiales','## Identificadores y materiales',1)
s=s.replace('La construcción es conjunta, de Adro y GPT. Adro leyó el manuscrito completo y aportó la revisión integral.','La construcción del informe es conjunta, de Adro, GPT y Claude. Adro leyó el manuscrito completo y aportó la revisión integral. Claude contribuyó mediante contrastes, propuestas y revisiones; el trabajo con Opus añadió la capa de integridad del archivo.')
s=s.replace('Adro y GPT construyeron el texto mediante esas intervenciones sucesivas. Los contrastes y las revisiones con Claude aportaron otras lecturas; el trabajo con Opus añadió, entre otros materiales, la capa de integridad del archivo. El conjunto conserva las contribuciones y las discrepancias que modificaron su forma.','Adro, GPT y Claude participaron en la construcción de este informe. El recorrido principal de Adro y GPT se amplió con los contrastes, las propuestas y las revisiones de Claude; el trabajo con Opus añadió, entre otros materiales, la capa de integridad del archivo. Las contribuciones tuvieron alcances distintos y todas forman parte del resultado. La autoría compartida recoge ese trabajo y las discrepancias que modificaron el texto.')
s=s.replace('El informe queda abierto a otras lecturas y a las próximas decisiones de ambos.','El informe queda abierto a otras lecturas y a futuras revisiones conjuntas.')
s=s.replace('Esta edición reúne el desarrollo integral para lectura conjunta:','Esta edición preprint reúne el desarrollo integral:',1)
s=s.replace('Las siguientes revisiones conjuntas pueden modificar contenido, conexiones y presentación.','Las futuras versiones pueden incorporar revisiones conjuntas de contenido, conexiones y presentación.')
s=s.replace('discutidos en esta conversación.','discutidos durante la preparación del manuscrito.')
s=s.replace('aportado con su enlace directo por Adrian Valenzuela en esta conversación el 26/10/2026','aportado con su enlace directo por Adrian Valenzuela durante la preparación del manuscrito el 26/10/2026')
s=s.replace('Los tests completos, resultados y auditorías se reunirán en los repositorios de materiales del proyecto; sus destinos finales se incorporarán a la edición de publicación. Las fichas y auditorías utilizadas aquí ya se enlazan en el registro de fuentes.','El repositorio [ENFOQUE-NUEVO-MATERIALES](https://github.com/adro-2026/ENFOQUE-NUEVO-MATERIALES) es el destino documental de los tests, resultados y auditorías del informe. Las fichas y auditorías utilizadas aquí se enlazan también en el registro de fuentes.')
s=re.sub(r'\*\*Fin del manuscrito integral v0\.23\.\*\* Texto para revisión conjunta sobre sus secuencias, fuentes y conexiones\. El HTML permanece como guía de acceso al conjunto\.','',s)

# Keep the source's transcription convention for signals, with exact codepoints in an endnote.
signals={
 '👉🏼📞🖼️':'[señalar / llamada / imagen]',
 '🫡🆗':'[saludo / OK]',
 '❌🚩':'[cruz / bandera]',
 '👀✅✅':'[ojos / confirmación / confirmación]',
 '🔑📝🐘🆗🗂️':'[llave / nota / elefante / OK / archivo]'
}
for a,b in signals.items():s=s.replace(a,b)
note='En este capítulo, los grupos de emojis se transcriben entre corchetes por sus nombres para mantener legible la secuencia. Los signos originales y sus códigos se conservan en las fuentes y en la nota técnica de esta edición.'
s=s.replace('## 03. Un punto, una señal, una imagen y su registro\n','## 03. Un punto, una señal, una imagen y su registro\n\n'+note+'\n',1)
technical='\n\n### Transcripción de señales\n\nLos nombres entre corchetes preservan el orden de los signos originales. Sus secuencias Unicode son:\n\n'
for chars,label in signals.items():
    technical+=f'- **{label.strip(chr(91)+chr(93))}:** '+', '.join(f'U+{ord(c):04X}' for c in chars)+'.\n'
s=s.replace('## I. Léxico operativo',technical+'\n## I. Léxico operativo',1)

# Carry existing anchor identities into the rendered headings.
s=re.sub(r'<a id="([^"]+)"></a>\s*\n(#+ [^\n]+)',lambda m:m[2]+' {#'+m[1]+'}',s)
s=re.sub(r'<!--.*?-->','',s,flags=re.S)
s=s.replace('# Prefacio — Adro','# Prefacio - Adro').replace('# Apertura —','# Apertura -')

figures=[]
def fig(path,caption,label,width='100%'):
    figures.append({'label':label,'path':path,'caption':caption})
    return '\n\n![%s](figures/%s){#%s width=%s}\n\n'%(caption,path,label,width)
def before(heading,path,caption,label,width='100%'):
    global s
    assert heading in s,heading
    s=s.replace(heading,fig(path,caption,label,width)+heading,1)

before('# I — Construcciones dentro del recorrido','01_cronologia.pdf','Hitos seleccionados del recorrido. La disposición sigue el orden de lectura y no representa una escala temporal continua. Fuentes: S18-S20, S23-S24, S11, S01, S13, S03, S07, S14 y S09.','fig-cronologia')
before('## 02. Una carrera','02_rm.pdf','R/M: esquema de lectura de las distinciones desarrolladas en el capítulo. No sustituye la expresión histórica V2. La huella, el hito y la transformación conservan funciones diferentes. Fuente: S01.','fig-rm','95%')
before('# II — Leer el recorrido','03_senales.pdf','De la propuesta al registro en CONTRASTE 1. Los seis momentos condensan acciones del episodio; los signos se interpretan en su secuencia local. Fuente: S14.','fig-senales')
before('## 09. Corregir el dato','04_analogias.pdf','Tres recursos analógicos y lo que permiten hacer dentro de sus escenas. Los marcos y las fechas se mantienen diferenciados. Fuentes: S23, S22 y S13.','fig-analogias')
needle='La imagen participa en el intercambio: recoge material, lo organiza visualmente y recibe una lectura posterior. Puede volver más categórica una historia que en el diálogo estaba abierta. Esa transformación también merece análisis.'
assert needle in s
s=s.replace(needle,needle+fig('05_recorrido_original.png','Un Recorrido Compartido en Infinito. PNG original del 13/10, conservado como pieza del episodio y examinado en S04. La composición representa una respuesta del recorrido, no una conclusión añadida por esta edición.','fig-recorrido','76%'),1)
original='![Puntajes registrados en seis pruebas](../output/figuras/PANORAMA_PUNTAJES_TESTS_v0_9.png)'
assert original in s
s=s.replace(original,fig('06_puntajes.pdf','Puntajes registrados en seis pruebas, sobre 10. Cada panel conserva el criterio de su ficha; no hay promedio general. En T002 y T004 no se presenta una ejecución de C. T038 distingue Opus y Sonnet. Fuentes: fichas T002, T004, T021, T034, T037 y T038; S15 y S18.','fig-puntajes'))
needle='Los números permiten volver a lo que sucedió en cada tarea.'
s=s.replace(needle,fig('07_fases.pdf','Resultados de las tres fases del cruce A/C, con veinte casos por fase. Las entradas y la información disponible cambian entre fases; los valores describen tareas distintas. Fuente: S03, §6.4.','fig-fases')+needle,1)
before('## 29. El costo forma parte','08_costo.pdf','Intercambios desde explicar el encargo hasta obtener el acuerdo operativo en los tests del 17/10. Se cuentan entradas propias de Adro y respuestas de C dentro de esa ventana, no todo el trabajo ni el desgaste como magnitud. Fuente: S09.','fig-costo')
before('## 32. El acople','09_escalas.pdf','Escalas de lectura del informe. Una respuesta ocupa una posición dentro de una secuencia y de un recorrido; ampliar la ventana permite recuperar referentes, intervenciones y transformaciones. Síntesis del capítulo 31.','fig-escalas','95%')
before('## 33. Lo que cambia','10_holdout.pdf','Resultado comunicado por HOLDOUT: 42 retornos formales, diez candidatos que pasan los filtros disponibles y cero positivos fuertes validados tras revisión semántica. El control delimita una clase de retorno y sus candidatos. Fuentes: S12; S06, §6.','fig-holdout')
before('### Qué relación tiene con las fuentes del informe','11_integridad.pdf','Capas del compromiso público: manifiestos y raíces por corpus, raíz global, digest del archivo de raíz y sello con atestación Bitcoin. El orden del compromiso es distinto del orden conversacional. Fuente: S25 y sección K.','fig-integridad')

# Section boundaries become deliberate page breaks in the paper template.
s=re.sub(r'(?m)^(# [^\n]+)',r'\\clearpage\n\n\1',s)
s=s.replace('\\clearpage\n\n# II — Leer el recorrido','\\Needspace{8\\baselineskip}\n\n# II — Leer el recorrido')
# Main sections use an unnumbered index; chapter numbers already belong to the text.
metadata='''---
title: "Y si predecir no alcanza"
subtitle: "Una señal. Tres recorridos. Distintas huellas."
author: "Adro + GPT + Claude"
date: "27 de octubre de 2026 · Preprint 1.0"
lang: es
documentclass: article
fontsize: 11pt
papersize: a4
mainfont: DejaVu Serif
mainfontoptions: [AutoFakeSlant=0.17]
sansfont: DejaVu Sans
monofont: DejaVu Sans Mono
colorlinks: true
linkcolor: teal
urlcolor: teal
toc-depth: 2
---

'''
(ROOT/'manuscript.md').write_text(metadata+s.strip()+'\n')
(ROOT/'figures_manifest.json').write_text(json.dumps(figures,ensure_ascii=False,indent=2))
print('Prepared manuscript, authorship, 11 figures and signal transcription note.')
