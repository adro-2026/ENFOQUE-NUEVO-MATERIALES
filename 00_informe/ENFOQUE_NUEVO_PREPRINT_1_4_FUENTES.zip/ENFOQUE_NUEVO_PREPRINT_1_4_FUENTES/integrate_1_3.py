from pathlib import Path
import re, csv, json

root=Path(__file__).resolve().parent
src=(root/'source_input/BASE_PREPRINT_1_2.md').read_text()
new=(root/'new_sections.md').read_text()
parts={m.group(1):m.group(2).strip() for m in re.finditer(r'<!-- (\w+) -->\n(.*?)(?=<!-- \w+ -->|\Z)',new,re.S)}
matches=list(re.finditer(r'^## (\d\d)\. (.+?) \{#capitulo-\d\d\}\n',src,re.M))
chap={}
titles={}
for i,m in enumerate(matches):
    end=matches[i+1].start() if i+1<len(matches) else src.index('# Reflexión sobre')
    block=src[m.end():end]
    block=re.split(r'^# ',block,flags=re.M)[0]
    # The scene precedes former chapter 04 and is not part of chapter 03.
    block=block.split('## Una coma cambia el referente')[0]
    block=re.sub(r'\n\\Needspace\{\d+\\baselineskip\}\s*$', '',block)
    k=int(m.group(1)); chap[k]=block.strip(); titles[k]=m.group(2)

def chapter(k,title=None):
    return f'## {title or titles[k]} {{#capitulo-{k:02d}}}\n\n'+chap[k]+'\n\n'

# Correct the body and the technical documentation together.
chap[14]=chap[14].replace('La ventana de A contiene cuarenta y una entradas del usuario hasta el cierre del eje y se extiende aproximadamente una hora y quince minutos.', 'La cadena activa de A contiene treinta y ocho entradas del usuario hasta el cierre del eje, incluidos adjuntos, y se extiende aproximadamente una hora y quince minutos. Tres entradas alternativas explican el total anterior de cuarenta y una. [S29, traza §4]')
chap[14]=chap[14].replace('En A, parte de la extensión corresponde a producir y revisar.', 'En A, la extensión combina producción, revisión y restitución del criterio. El original muestra cambios de evaluación y, ante una nueva foto, Adro pregunta: «y el conductor del fuego, ¿dónde quedó?». [S29, E04-04/06]')
chap[29]=chap[29].replace('El tiempo se utiliza para producir y revisar.', 'El intercambio combina producción, revisión y restitución del hilo visual, como muestra el análisis de T023 en la sección 5.')
chap[29]=chap[29].replace('Reunir estas escenas permite volver a las tres entradas del informe con más historia: un formato tiene un origen, una analogía puede sostener trabajo compartido y una señal puede recuperar o perder su función. Las conexiones que siguen distinguen esas continuaciones de los enlaces propuestos durante esta lectura.','')
chap[28]=chap[28].replace('Aceptaciones y nuevas negativas siguen alternándose.', 'La condición de C sobre no insistir tras una negativa permanece estable. Las reaperturas afectan al transporte de voz y a la atribución de los textos que había aceptado recibir. [S29, E06]')
chap[10]=chap[10].replace('Después del trabajo sobre la v0.13,', 'Durante una revisión del manuscrito,')
chap[10]=chap[10].replace('El cotejo actual confirma los enlaces', 'El cotejo JSON documentado en el anexo H confirma los enlaces')
chap[10]=chap[10].replace('el cotejo dirigido de esta edición vuelve a localizar sus entradas', 'el cotejo dirigido documentado en la base localiza sus entradas')
chap[10]=chap[10].replace('La grabación permite leer la espera y la aparición.', 'El anotador de la grabación documenta la espera y la aparición.')
chap[29]=chap[29].replace('En la entrega de la v0.13', 'En el episodio de entrega del manuscrito')
chap[29]=chap[29].replace('Preparación de la v0.13', 'Preparación del manuscrito, S28')

scene=src[src.index('## Una coma cambia el referente'):src.index('## 04.')].strip()
preface=src[src.index('# Prefacio - Adro'):src.index('# Apertura')].strip()
preface=re.sub(r'\n\\Needspace\{\d+\\baselineskip\}\s*$','',preface)
voice=chap[8][:chap[8].index('### Un antecedente:')].strip()
voice=voice.removesuffix('---').strip()
rest8=chap[8][chap[8].index('### Un antecedente:'):]
rest8=rest8.replace('La continuación pasa por la imagen de un eco y termina elaborando “silencio operativo” y “eco operativo”.', 'El 1 de marzo, Adro introduce la imagen del eco y propone «eco operativo»; la continuación elabora esa propuesta junto a «silencio operativo».')
rest8=rest8.replace('La escena de agosto desarrollada al abrir la parte II muestra el regreso de la galería y del preset para hablar de la propia interacción. Ese uso prolonga el trabajo de febrero: la fotografía sirve para transmitir una diferencia y para examinar cómo la respuesta la interpreta. [S22; S23]', 'Las escenas de febrero y agosto reutilizan galería, preset y ajuste con funciones distintas. En febrero permiten integrar fricción e historia de aprendizaje; en agosto señalan un referente que la respuesta todavía no recoge. La comparación reconstruye esa transformación del recurso. La ventana de agosto no contiene una remisión explícita al marco de febrero. [S22; S23; S30]')

yaml=src[:src.index('## Nota de lectura')].replace('Preprint 1.2','Preprint 1.3').replace('toc-depth: 2','toc-depth: 1')
ids=src[src.index('## Identificadores y materiales'):src.index('\\clearpage')].strip()
ids=ids.split('El repositorio reunirá')[0].strip()

front=yaml+parts['INTRO']+'\n\n'+ids+'\n\n\\clearpage\n\\begingroup\n\\setlength{\\parskip}{0pt}\n\\tableofcontents\n\\endgroup\n\\clearpage\n\n'+preface+'\n\n'
body=front
body+='# 1. Tesis y escena de entrada {#tesis}\n\n'+parts['THESIS']+'\n\n'+scene+'\n\n'
body+=chapter(7)
body+='# 2. Participantes, archivo y método {#metodo}\n\n'+chapter(5)+parts['METHOD']+'\n\n'+chapter(12)
body+='# 3. Genealogías de recursos {#genealogias}\n\n'+voice+'\n\n'+parts['GENEALOGIES']+'\n\n'+chapter(13)
body+='# 4. Construcciones y transformación del objeto {#construcciones}\n\n'
body+='R/M, la carrera y las señales permiten seguir objetos que cambian mediante contribuciones sucesivas. T023 añade una propuesta de producción conjunta y el reparto que recibe al probarla. Las escenas siguientes desarrollan esos procesos; la sección 5 los compara por operaciones.\n\n'
for k in [1,2,3,14,20]: body+=chapter(k)
body+='\\Needspace{40\\baselineskip}\n\n# 5. Comparación transversal: interpretar, hacer y sostener {#comparacion}\n\n'+parts['MATRIX']+'\n\n'
for k in [9,11,16,17,19,21,22,23]: body+=chapter(k)
body+='# 6. Transporte, interrupción y trabajo de continuidad {#transporte}\n\n'
for k in [18,24,25,26,27,28,29]: body+=chapter(k)
body+='# 7. Reconstruir el acontecimiento entre registros {#registros}\n\n'+chapter(10)+parts['RECORDS']+'\n\n'
body+='# 8. Resultados adversos, equivalencias y HOLDOUT {#adversos}\n\n'+parts['ADVERSES']+'\n\n'+chapter(15)+chapter(6)
body+='# 9. Discusión y contribuciones {#discusion}\n\n'+parts['DISCUSSION']+'\n\n'
# Retain the existing scales figure at the argument's point of synthesis.
body+='![Escalas de lectura: respuesta, secuencia y recorrido. La comparación identifica referentes, intervenciones y transformaciones en ventanas de distinto alcance. Fuentes: S29–S32.](figures/09_escalas.pdf){#fig-escalas width=95%}\n\n'
body+='# 10. Conclusiones {#conclusiones}\n\n'+parts['CONCLUSIONS']+'\n\n'
reflection=src[src.index('# Reflexión sobre'):src.index('# Sección técnica')]
reflection=reflection.replace('La lectura completa de Adro produjo esta nueva revisión:', 'La lectura completa de Adro orientó las revisiones del manuscrito:')
body+=reflection
tech=src[src.index('# Sección técnica'):src.index('# Registro de fuentes')]
tech=re.sub(r'## J\. Estado de esta edición\n.*?(?=## K\.)', '''## J. Estado de esta edición

La edición 1.3 organiza el cuerpo en diez secciones e integra tres genealogías con 44 eventos, una matriz de 34 segmentos de seis episodios, un procedimiento de correspondencia entre registros y el posicionamiento frente a seis antecedentes. Las fuentes S29–S32 identifican los análisis incorporados, sus tablas y trazas. La apertura histórica extensa y el desarrollo complementario de analogías pasan al anexo M.

T023 distingue 38 entradas activas y tres alternativas; S28 identifica la discrepancia de tamaños y revisiones. Los números N de la genealogía se convierten de base uno a base cero. M/C/F y A1/C1/A2/C2 mantienen sus localizadores de origen. Las afirmaciones sobre observación visual siguen distinguiendo activos inspeccionados e informes derivados.

Se mantienen íntegros el prefacio y el texto original de Adro sobre analogías. Las treinta y nueve fichas utilizadas, las tres auditorías PLUS, los resultados favorables a C y el cero de HOLDOUT siguen integrados. Las fuentes de composición incluyen los análisis recibidos y el script de integración para reproducir los cambios.

La capa de integridad de K corresponde al paquete público comprobado durante la preparación de la base. Esta reorganización editorial no altera el conjunto comprometido. Los datos crudos y las claves privadas permanecen fuera de las fuentes públicas.

''',tech,flags=re.S)
old=re.search(r'\*\*S28 — preparación de la v0\.13\.\*\*.*?(?=\n\n\n|### Transcripción)',tech,re.S)
assert old
replacement='''**S28 — preparación del manuscrito.** El registro contemporáneo reúne la declaración de Adro y la captura 1000505232.jpg, inspeccionada durante la preparación de la base. En la integración transversal se consultó independientemente el historial de los dos IDs de Drive. Las revisiones nombradas v0_12 tienen MD de 221.218 bytes y PDF de 4.441.174 bytes, guardados el 27/10 a las 01:56:25.085 y 01:56:30.776 UTC. Las nombradas v0_13 tienen 233.287 y 4.458.651 bytes, guardados a las 02:24:27.999 y 02:24:33.877 UTC. Se corrige así la asociación previa de tamaños con v0.13. Los metadatos acreditan guardados; identificar definitivamente la versión interna del episodio exige contenido histórico y referencia temporal de la captura. [S31]

**Cobertura de S31.** Se leyeron los nueve anotadores S27 y el texto principal A06. Los paquetes S26 y S20 no se reabrieron en ese encargo por fallos de recuperación; el caso de marzo utiliza el cotejo anterior documentado arriba. No se declara una nueva inspección de todos los vídeos ni de la captura original. A05 tiene duración 11,889932 segundos; su anotador no fija la duración exacta del estado gris. A06 distingue quince ciclos: once con salida visual y cuatro detenciones deliberadas (G4, G9, G12 y G14). Sus familias visuales A/B/C no designan las cuentas. [S31, matriz y disponibilidad]'''
tech=tech[:old.start()]+replacement+tech[old.end():]
tech+='\n\n## M. Historia y desarrollos complementarios {#historia-complementaria}\n\nEste anexo mantiene las escenas históricas y los desarrollos analógicos que permiten ampliar la lectura de las genealogías. El cuerpo concentra sus transformaciones y siguientes usos.\n\n'+chapter(0)+'## Antecedentes y desarrollos de las analogías {#capitulo-08}\n\n'+rest8+'\n\n'
# Expand the claim map without changing earlier trace entries.
needle='## C. Cronología de lectura'
addition='''### Resultados transversales incorporados

| Afirmación | Fuente y ventana | Comprobación |
|---|---|---|
| Juego, formato elegido y nombre son hitos distintos | S30, P01–P03 | 14, 19 y 21 de febrero; UUID en la traza. |
| Tres señales tienen correspondencias anteriores localizadas | S30, señales S01–S04 | Marzo, agosto y septiembre; contextos y UUID. |
| Interpretación, aceptación, ejecución y mantenimiento se separan | S29, E01–E06 | 34 segmentos con oportunidades posteriores. |
| T023 contiene 38 entradas activas y tres alternativas | S29, traza §4 | Cadena N3–94 y tres UUID fuera de ella. |
| Los tamaños citados de S28 corresponden a revisiones nombradas v0_12 | S31; historial de Drive | Tamaños y tiempos de revisiones v0_12/v0_13. |
| HOLDOUT reporta cero positivos fuertes entre diez candidatos | S12; S32 | Partición, filtros y adjudicación semántica separados. |

'''
tech=tech.replace(needle,addition+needle)
body+=tech
registry=src[src.index('# Registro de fuentes'):]
registry=registry.replace('confirmaciones de reemplazo de la v0.13.', 'confirmaciones de reemplazo del manuscrito. La revisión S31 corrige la asociación de tamaños y nombres históricos de versión.')
newrefs='''- **S29.** [Matriz comparativa de seis episodios](https://drive.google.com/file/d/1pIGUe6pH3GUBryXd3bdzSIxEJLlD0--r/view), [CSV de 34 segmentos](https://drive.google.com/file/d/1Lkxe12hcc-jiLK2yHjaID2bZnaGljXUe/view) y [traza de operaciones](https://drive.google.com/file/d/19cUAGf00-QkpYmJ7oF_4ESzptZui-T_b/view). Encargo 01, 27/10/2026. Incluye recuento del original de T023 y distinción de ramas.
- **S30.** [Genealogías de tres recursos](https://drive.google.com/file/d/1mbMiVIw-KVq7lhphmHBQv9tOvmBFLOVJ/view), [cronología de 44 eventos](https://drive.google.com/file/d/1TdeBLN3uxl5wuPeYIXMCjoquOwqro5UB/view) y [traza](https://drive.google.com/file/d/1P9eMsw8l7vD4ncn6u_siHGhuqCepInZm/view). Encargo 02, 27/10/2026. La fuente usa N1b; esta edición convierte esos índices a N desde cero.
- **S31.** [Método de registros complementarios](https://drive.google.com/file/d/1i__5mejunyXu_AXjhFAjZsHiWw1SYA7N/view), [matriz](https://drive.google.com/file/d/1aUeUTeKk8B2ZF4i9uq37yPZ6qKO1xbfe/view) y [traza y disponibilidad](https://drive.google.com/file/d/1HOOm4tfcRSfo6jOsozh-oITD-WiZAm9-/view). Encargo 03, 27/10/2026. Niveles de acceso diferenciados. Se repitió el cotejo de metadatos de revisiones S28 durante la integración.
- **S32.** [Antecedentes y posicionamiento](https://drive.google.com/file/d/1bhRjlVvDiQMNHO5W1yh6cnIvIfgGU7Wh/view), [matriz de seis trabajos](https://drive.google.com/file/d/1dsGrU1T5kycpMpkZhKw7l1wet2y47i5f/view) y [propuesta de estructura](https://drive.google.com/file/d/12FHxh5i6MaReRvKd0Ag3w6KXo1gW-opl/view). Encargo 04, 27/10/2026. Sus pendientes se actualizan al integrar S29–S31 y su cifra de T023 se corrige con S29.

'''
registry=registry.replace('\\Needspace{27\\baselineskip}',newrefs+'\\Needspace{10\\baselineskip}')
body+=registry
body+='\n\n\\clearpage\n# Referencias bibliográficas {#bibliografia}\n\n'
rows=list(csv.DictReader((root/'analysis_inputs/04_MATRIZ_BIBLIOGRAFICA.csv').open()))
authors=['Shaikh, O., Gligorić, K., Khetan, A., Gerstgrasser, M., Yang, D. y Jurafsky, D.', 'Shaikh, O., Mozannar, H., Bansal, G., Fourney, A. y Horvitz, E.', 'Sterken, R. K. y Kirkpatrick, J. R.', 'Yun, B., Taranova, E. y Wang, A. Y.', 'He, W. P. y Kim, M.', 'Michel, L., Pacheco, N. M. M., Ulan uulu, C., Kulyabin, M., Joosten, J., Petridis, F., Hedderich, M. A. y Plank, B.']
for i,(row,a) in enumerate(zip(rows,authors),1):
    body+=f"**B{i}.** {a} ({2024 if i==1 else 2025 if i in [2,3] else 2026}). *{row['trabajo']}*. {row['version_publicacion']}. [Texto primario]({row['enlace_primario']}).\n\n"
body+='B5 y B6 se consultaron el 27/10/2026: sus PDF ya estaban disponibles y llevan fechas impresas de 29 y 28 de octubre. El registro de S32 documenta el acceso y la versión leída.\n'

# Replace stale chapter-number references with the destination section.
dest={0:'el anexo M',1:'la sección 4',2:'la sección 4',3:'la sección 4',4:'la sección 1',5:'la sección 2',6:'la sección 8',7:'la sección 1',8:'la sección 3 y el anexo M',9:'la sección 5',10:'la sección 7',11:'la sección 5',12:'la sección 2',13:'la sección 3',14:'la sección 4',15:'la sección 8',16:'la sección 5',17:'la sección 5',18:'la sección 6',19:'la sección 5',20:'la sección 4',21:'la sección 5',22:'la sección 5',23:'la sección 5',24:'la sección 6',25:'la sección 6',26:'la sección 6',27:'la sección 6',28:'la sección 6',29:'la sección 6',30:'la sección 9',31:'la sección 10'}
body=re.sub(r'(?i)(?:el )?capítulo (\d{1,2})(?!\d)',lambda m:dest.get(int(m.group(1)),m.group()),body)
body=body.replace('al abrir la parte II','en la sección 1').replace('la parte III','la sección 5')
body=body.replace('la parte II','la sección 1').replace('de la parte de octubre','de los cruces de octubre')
body=body.replace('S01–S28','S01–S32')
body=body.replace('dla sección','de la sección').replace('dla anexo','del anexo').replace('en la sección 3 y el anexo M','en la sección 3 y en el anexo M')
body=body.replace('una señal puede recuperar o perder su función','una señal puede mantener o cambiar su función')
# Remove redundant layout controls, retaining actual document transitions.
body=re.sub(r'\\Needspace\{\d+\\baselineskip\}\s*(?=\n?#)', '',body)
body=re.sub(r'(?m)^(# \d+\.)',r'\\FloatBarrier\n\n\1',body)
body=re.sub(r'\n{4,}','\n\n\n',body)
body=body.replace('\\FloatBarrier\n\n# 5.', '\\FloatBarrier\n\\Needspace{42\\baselineskip}\n\n# 5.')
for before,after in {
 'La reconstrucción conserva':'La reconstrucción documenta',
 'La secuencia conserva':'La secuencia muestra',
 'El registro conserva':'El registro documenta',
 'La tabla conserva las palabras':'La tabla reproduce las palabras',
 'T005 se conserva como PLUS cualitativo':'T005 se presenta como PLUS cualitativo',
 'se conserva aparte':'se presenta por separado',
 'El contraste conserva un episodio en el que C interpreta mejor':'El contraste muestra que C interpreta mejor',
 'El caso conserva dos convenciones de conteo':'El caso utiliza dos convenciones de conteo',
 'T030 conserva una comparación cualitativa':'T030 presenta una comparación cualitativa',
 'Cada fila conserva el criterio':'Cada fila utiliza el criterio',
}.items(): body=body.replace(before,after)
(root/'manuscript.md').write_text(body)
(root/'header.tex').write_text((root/'header.tex').read_text().replace('1.2','1.3').replace('Revisión de composición','Genealogías y comparación transversal').replace('\\setcounter{tocdepth}{2}','\\setcounter{tocdepth}{1}'))
(root/'build_pdf.py').write_text((root/'build_pdf.py').read_text().replace('1_2','1_3'))
print(json.dumps({'chars':len(body),'sections':len(re.findall(r'^# \d+\.',body,re.M)),'input_chapters':len(chap),'figures':len(re.findall(r'^!\[',body,re.M)),'old_chapter_references':re.findall(r'capítulo \d+',body)},ensure_ascii=False))
