# Y si predecir no alcanza - Preprint 1.4

Adro + GPT + Claude. 27 de octubre de 2026.

Edición de cierre editorial: incorpora «Cómo leer este informe» y reúne al inicio datos, DOI, repositorio, ORCID y acceso a la trazabilidad. Presenta el repositorio como público para la publicación prevista; esta edición no modifica su visibilidad ni incorpora archivos a GitHub. La pasada de redacción sustituye instrucciones y notas de trabajo por resultados y descripciones del alcance documental. El interlineado es 1.22 y el espaciado de tablas 1.26, independientes del número de versión.

El cuerpo mantiene diez secciones, tres genealogías (44 eventos), matriz de seis episodios (34 segmentos), método de correspondencia entre registros y discusión con seis antecedentes. T023 distingue 38 entradas activas y tres alternativas; S28 especifica tamaños y revisiones. Los textos originales de Adro, los resultados favorables a C y la regla y resultado de HOLDOUT permanecen íntegros. El anexo M amplía las escenas históricas y los desarrollos de las analogías.

## Archivos y reconstrucción

- `manuscript.md`: texto de esta edición.
- `header.tex`, `layout.lua`: estilo y reglas de tablas.
- `figures/`: 19 figuras utilizadas, con copias de inspección.
- `analysis_inputs/`: los 13 archivos entregados por los cuatro encargos.
- `new_sections.md`: redacción nueva integrada.
- `integrate.py`: aplica el cierre editorial a la base 1.3.
- `opening_guide.md`: guía de lectura y resumen de datos e identificadores.
- `source_input/BASE_PREPRINT_1_3.md`: base de esta pasada editorial.
- `source_input/BASE_PREPRINT_1_2.md`: base editorial de la integración.
- `source_input/INFORME_v0_23.md`: antecedente anterior a las revisiones editoriales.
- `VERIFICACION.json`: comprobaciones locales y alcance de revisión.

Desde esta carpeta, ejecutar `python3 build_pdf.py`. Requiere Pandoc, XeLaTeX, xdvipdfmx y las fuentes URW Base35 y DejaVu. El PDF se escribe en `build_review/ENFOQUE_NUEVO_PREPRINT_1_4.pdf`.

Las figuras ya están incluidas. `transversal_figures.py` reconstruye las tres del análisis transversal. `make_figures.py` y `extra_figures.py` reconstruyen las anteriores, salvo el PNG histórico que se mantiene como dato. Para regenerar el texto desde la base, ejecutar `python3 integrate.py` antes de compilar. `integrate_1_3.py` y `new_sections.md` documentan la integración anterior. Las observaciones de los encargos son documentos de trabajo: el manuscrito incorpora las correcciones cruzadas; no deben sustituirlo automáticamente.

La revisión documental de integración no repite el análisis primario completo de todos los originales. La cobertura de registros visuales y las versiones históricas se especifican en H y S29-S32. Este paquete contiene fuentes de composición y análisis derivados; no incluye los exports crudos ni claves privadas.
